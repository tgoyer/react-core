import React from 'react';
import { Link } from "react-router-dom";
import injectSheet from "react-jss";

const styles = theme => ({
    header: {
        ...theme.fonts.title,
        gridColumnEnd: 'span 2',

        backgroundColor: theme.colors.tertiary.background,
        color: theme.colors.tertiary.text,

        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 20,
    },
    logo: {
        height: 45,
        width: 45,
        marginRight: 30,
        '& img': {
            backgroundColor: '#000000',
            boxShadow: '0 0 0px 3px rgba(255, 255, 255, .5)',
            height: '100%',
            width: '100%',
        }
    },
});

const Header = (props) => {
    const { classes } = props;

    return (
        <header className={classes.header}>
            <Link to="/" className={classes.logo}><img src={process.env.PUBLIC_URL + '/images/logo.svg'} alt="Alliance Bernstein" /></Link>
            <span>ReactCore Demo App</span>
        </header>
    );
}

export default injectSheet(styles)(Header);