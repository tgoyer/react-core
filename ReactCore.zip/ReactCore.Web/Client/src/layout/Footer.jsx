import React from 'react';
import injectSheet from "react-jss";

const styles = theme => ({
    footer: {
        ...theme.fonts.subtitle,
        gridColumnEnd: 'span 2',

        backgroundColor: theme.colors.tertiary.background,
        color: theme.colors.tertiary.text,

        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingLeft: 20,
        '& a': {
            ...theme.fonts.subtitle,
            ...theme.fonts.link,
            color: theme.colors.tertiary.text,
            marginLeft: 5,
            '&:hover': {
                color: theme.colors.tertiary.text,
                textDecoration: 'underline',
            },
            '&:active': {
                color: theme.colors.tertiary.text,
            },
            '&:visted': {
                color: theme.colors.tertiary.text,
            },
        }
    },
});

const Main = (props) => {
    const { classes } = props;
    
    return (
        <footer className={classes.footer}>
            <span>&copy; { new Date().getFullYear() } <a href="https://www.alliancebernstein.com/">AllianceBernstein L.P.</a></span>
        </footer>
    );
}

export default injectSheet(styles)(Main);